<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="Requirment Update.css">
	<title>My Website</title>
	<script src="https://code.iconify.design/1/1.0.7/iconify.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
<style>

/*body {

	background-image: url("https://images.squarespace-cdn.com/content/v1/577eab6d03596e5318b18a43/1567780758186-7JTX3QN8EJ2L3JBNX641/ke17ZwdGBToddI8pDm48kDHPSfPanjkWqhH6pl6g5ph7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z4YTzHvnKhyp6Da-NYroOW3ZGjoBKy3azqku80C789l0mwONMR1ELp49Lyc52iWr5dNb1QJw9casjKdtTg1_-y4jz4ptJBmI9gQmbjSQnNGng/Hold+a+hand%2C+change+a+life");
	background-attachment: fixed;  
	background-size: cover;
	font-weight: bold;
	font-family:'Trebuchet MS';
	font-size: 20px;
	text-align: center;

}

a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 10px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: blue;
}*/
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    
}
:root{
  --border-radius: 15px;
  --gap: 49px;
  --bg-color: rgba(10,10,10);
  --text-color: rgb(143,143,143);
  --accent-color: #18caca;
  --outer-shadow-lg: 4px 6px 12px rgba(171, 170, 165, 0.88), -13px -6px 12px rgba(255, 255, 255, 0.1);
    --outer-shadow-sm: 0px 1px 2px rgba(130,125,125), -6px -3px 6px rgba(255,255,255,.1);
  --inner-shadow-sm: 3px 3px 6px rgba(174,166,166,0.71), inset -3px -3px 6px rgba(255,255,255,.1);
}
.toggles-container{
  color: var(--text-color);
  width: 316px;
  height: 305px;
  padding: var(--gap);
  display: grid;
  grid-template-columns: repeat(7,1fr);
  grid-template-rows: repeat(7,1fr);
  grid-column-gap: var(--gap);
  grid-row-gap: var(--gap);
  
  border-radius: var(--border-radius);
  
}
.toggle-box{
  border-radius: var(--border-radius);
  box-shadow: var(--outer-shadow-sm);
  display: flex;
  width: 50px;
    
  height: 40px;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: box-shadow 700ms ease, color 700ms ease;
}
.toggle-pressed{
  box-shadow: var(--outer-shadow-sm),var(--inner-shadow-sm);
  color: var(--accent-color);
}
.toggle-icon{
  font-size: 35px;
  padding: 10px;
}
.side{
    position: absolute;
    left: -30%;
   
}
.pic{
    position: absolute;
    top: 5%;
    left: 3%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.box{
    background: #fff;
    padding: 20px 25px;
    border-radius: 5px;
  height: 1300px;
    width: 840px;
    position: absolute;
    top: 22%;
    left: 20%;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
.head{
  font-size: x-large;
  position: absolute;
  top: 20px;
  left: 34%;
color: black;
   

   
   }
   
   .box h1{
     font-weight: bold;
     background: -webkit-linear-gradient(150deg,rgb(27, 197, 197),palegreen);
    /* -webkit-background-clip: text;*/
   -webkit-text-fill-color: transparent;
   }
  
   .iconify{
     font-size: 30px;
   }
   .line{
    height: 4px;
    width: 510px;
    border-radius: 6px;
    position: absolute;
    left: 32%;
    top: 15%;
    background: linear-gradient(to left,rgb(43, 190, 183),rgb(3, 44, 42));
 }
 
.row {
    display: flex;
    flex-wrap: wrap;
    padding: 0 4px;
  }
  
  /* Create four equal columns that sits next to each other */
  .column {
    flex: 205%;
    max-width: 9.95%;
    padding: 0 4px;
  }
  
  .column img {
    margin-top: 8px;
    vertical-align: middle;
    width: 100%;
    filter: grayscale(1) brightness(0.5);
    border-radius: 5px;
    border: white;
    cursor: pointer;
    transition: 0.3s linear;
  }
  .column img:hover {
    filter: grayscale(0);
  }
  @media screen and (max-width: 900px) {
    .column {
      flex: 50%;
      max-width: 50%;
    }
  }
  
  /* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
  @media screen and (max-width: 600px) {
    .column {
      flex: 100%;
      max-width: 100%;
    }
    .column img {
      filter: grayscale(0) brightness(1);
    }
  }
  .container {
    width: 500px;
    margin: 30px auto;
    margin-left: 10px;
    }
   <tr><td> input {
    width: 300px;
    font-size: 18px;
    margin: 10px;
    padding: 8px;
    }
    .remove {
    width: 30px;
    height: 30px;
    font-size: 20px;
    background-color: tomato;
    color: white;
    border: none;
    outline: none;
    border-radius: 15px;
    }
    #addRow {
    width: 130px;
    outline: none;
    height: 40px;
    font-size: 16px;
    background-color: lightseagreen;
    color: white;
    border: none;
    margin: 20px;
    }
    button:hover {
    cursor: pointer;
    }
    tr:hover {
    cursor: move;
    }
    .mid{
        font-size: 30px;
        font-weight: bold;
        margin-top: 270px;
        margin-left: 40px;
        font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        
    }
    .mid span{
        color: lightseagreen;
    }
    .name<tr><td> input{
        width: 200px;
    }
    .firstname{
        position: relative;
        left: 150px;
        top: -42px;
        line-height: 40px;
        border-radius: 6px;
        padding: 0 22px;
        font-size: 16px;
        outline: none;
        }
        .firstlabel{
            position: relative;
            left: 162px;
            top: -45px;
            font-weight: bold;
            font-size: 14px;
            color: #141616;
            text-transform: capitalize;
            
            }
            .cta2{
              display: inline-block;
              padding: 10px 30px;
              color: white;
              background-color: rgb(145, 146, 146);
              border: 2px solid rgb(53, 158, 161);
              font-size: 2rem;
              text-transform: uppercase;
              text-decoration: none;
              letter-spacing: .1rem;
              margin-top: 30px;
              margin-left: 280px;
              transition: .3s ease;
              transition-property: background-color, color;
            }
            .cta2:hover {
              color: white;
              background-color:  rgb(107, 109, 109);
            }
            .center {
              position:absolute;
              top:90%;
              left:50%;
              transform:translate(-50%,-50%);
            }
            .popup {
              width:350px;
              height:280px;
              padding:30px 20px;
              background:#f5f5f5;
              border-radius:10px;
              box-sizing:border-box;
              z-index:2;
              text-align:center;
              opacity:0;
              top:100%;
              transform:translate(-50%,-50%) scale(0.5);
  transition: opacity 300ms ease-in-out,
              top 1000ms ease-in-out,
              transform 1000ms ease-in-out;
}
.button{
  background-color: #3BAF9F;
  display: block;
  margin: 60px 0px 0px 250px;
  text-align: center;
  border-radius: 12px;
  border: 2px solid #366473;
  padding: 14px 110px;
  outline: none;
  color: white;
  cursor: pointer;
  transition: 0.25px;
}
.popup.active {
  opacity:1;
  top:85%;
  transform:translate(-50%,-50%) scale(1);
  transition: transform 300ms cubic-bezier(0.18,0.89,0.43,1.19);
}
.popup .icon {
  margin:5px 0px;
  width:50px;
  height:50px;
  border:2px solid #34f234;
  text-align:center;
  display:inline-block;
  border-radius:50%;
  line-height:60px;
}
.popup .icon i.fa {
  font-size:30px;
  color:#34f234;
} 
.popup .title {
  margin:5px 0px;
  font-size:30px;
  font-weight:600;
}
.popup .description {
  color:#222;
  font-size:15px;
  padding:5px;
}
.popup .dismiss-btn {
  margin-top:15px;
}
  .popup .dismiss-btn button {
    padding:10px 20px;
    background:#111;
    color:#f5f5f5;
    border:2px solid #111;
    font-size:16px;
    font-weight:600;
    outline:none;
    border-radius:10px;
    cursor:pointer;
    transition: all 300ms ease-in-out;
  }
  .popup .dismiss-btn button:hover {
    color:#111;
    background:#f5f5f5;
  }
  .popup > div {
    position:relative;
    top:10px;
    opacity:0;
  }
    .popup.active > div {
      top:0px;
      opacity:1;
    }
    .popup.active .icon {
      transition: all 300ms ease-in-out 250ms;
    }
    .popup.active .title {
      transition: all 300ms ease-in-out 300ms;
    }
    .popup.active .description {
      transition: all 300ms ease-in-out 350ms;
    }
    .popup.active .dismiss-btn {
      transition: all 300ms ease-in-out 400ms;
    }
#open-popup-btn{
      display: inline-block;
              padding: 10px 30px;
              color: white;
              background-color: rgb(145, 146, 146);
              border: 2px solid rgb(53, 158, 161);
              font-size: 2rem;
              text-transform: uppercase;
              text-decoration: none;
              letter-spacing: .1rem;
              margin-top: 30px;
              margin-left: 0px;
              transition: .3s ease;
              transition-property: background-color, color;
            }
#open-popup-btn:hover {
              color: white;
              background-color:  rgb(107, 109, 109);
            }
.regform{
  width: 800px;
  background-color: rgba(0,0,0,0.6);
  margin: auto;
  color: #FFFFFF;
  padding: 10px 0px 10px 0px;
  text-align: center;
  border-radius: 15px 15px 0px 0px;
  }
  
  .buttonCls{
       border-radius: 10px;
       width:200px;
       height: 25px;
       background-color:#003366;
       color:white;
       opacity: 0.5;
       font-size:18px;
    }
</style>
</head>





<body>

  <div>
    <?php
    
    if(array_key_exists('submit', $_POST)) 
        { 
          SaveDetails(); 
        }
      function SaveDetails()
        {
          $conn=mysqli_connect('localhost','root','','orphanage_');
          if ($conn->connect_error) 
          {
            die("Connection failed: " .$conn->connect_error); 
          }
          ?>
    <div class="regform"><h1>Thank you<br><br></h1>
	<h2>Your responce has been recorded<br></h2></div>
	<div align="center">
	<br>
	<a href="orphanage_details.php"><div class="buttoncls">ORPHANAGE DETAILS</div></a>&emsp;&emsp;&emsp;&emsp;<a href="home.html"><div class="buttoncls">HOME</div></a>
	</div>

   <?php
    
          if($_POST['needs']!="")
          {
            $firstname = $_POST["needs"];
            $fs="";
            foreach($firstname as $fs1 ){
                $fs.=$fs1;
            }
            $add = $_POST["name"];
          /*  $orphanage = $_POST["first_name"];*/
		  mysqli_query($conn, "INSERT INTO requirements(`Basic`, `Other`)
            VALUES('$fs','$add')");
            
             exit;
           }
          else 
          {
            echo '<script> alert("Please Fill all your details")</script>';
          }
        }     
     ?>
    </div>
	<div class="container-fluid">
		<div class="row">
		  <div class="column">
			
			
			<img src="https://p.kindpng.com/picc/s/50-508065_free-cartoon-books-download-kids-books-cartoon-hd.png" />
			<img src="https://is2-ssl.mzstatic.com/image/thumb/Purple6/v4/00/9d/11/009d1199-f12d-351e-d397-150ffec6b256/mzl.qnaqbtwp.png/750x750bb.jpeg" />
			<img src="https://media.newyorker.com/photos/5f2c85539a557880d973a759/1:1/w_1823,h_1823,c_limit/Buford-FrenchRice.jpg" />
			<img src="https://www.wallpapertip.com/wmimgs/13-134716_smiley-face-desktop-wallpaper-49025-src-smiley-face.jpg" />
			<img src="https://www.simplyrecipes.com/thmb/j_IZxLEP2tJjonCl3s7RiGnMuxo=/2000x1331/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2020__02__HTC-White-Rice-Lead-4-e5743ee4c63a40a0aec2f3abd9f1c097.jpg" />
			<img src="https://i.pinimg.com/originals/82/15/56/821556d35fd814575d7bc445987a57cc.jpg" />
		  <img src="https://media.newyorker.com/photos/5f2c85539a557880d973a759/1:1/w_1823,h_1823,c_limit/Buford-FrenchRice.jpg" />
		 
		
		</div>
  
  
		  <div class="column">
			<img src="https://previews.123rf.com/images/dianavasileva/dianavasileva1906/dianavasileva190600024/127476990-vector-illustration-of-clothes-donation-in-flat-style-concept-for-charity-day-illustration-of-giving.jpg" />
			<img src="https://i.pinimg.com/originals/fa/c7/39/fac73900c96a27677a2e14398467440c.jpg" />
			<img src="https://thumbs.dreamstime.com/b/hand-drawn-illustration-clothes-donate-charity-care-concept-hand-drawn-illustration-clothes-donate-charity-care-concept-172184835.jpg" />
			<img src="https://media.istockphoto.com/vectors/cardboard-box-with-books-for-donations-charity-colorful-vector-vector-id1178491737?k=6&m=1178491737&s=612x612&w=0&h=gyIsd771Ir_iH0B6sOJv-OvBtgO-nZP9xByAHhhGexg=" />
		
		  </div>
		  
		  <div class="column">
			<img src="https://thumbs.dreamstime.com/b/hand-drawn-illustration-clothes-donate-charity-care-concept-hand-drawn-illustration-clothes-donate-charity-care-concept-172184835.jpg" />
		   </div>
		  
		  <div class="column">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrjnFNPWuGEZ1Mq6fOW4tf7h-bTZcrk7-zQizzrNnSfOjsx-lHwVyDGrjlCiv82QYzs2A&usqp=CAU" />
			<img src="https://i.pinimg.com/originals/af/eb/7d/afeb7d261617e39d54bc023bcaf2739c.jpg" />
			<img src="https://i.pinimg.com/474x/99/06/6f/99066fff5e69ba893213ee2671fc7dab.jpg" />
			<img src="https://www.how-to-draw-funny-cartoons.com/image-files/cartoon-tv-5.gif" />
		  </div>
		  <div class="column">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrjnFNPWuGEZ1Mq6fOW4tf7h-bTZcrk7-zQizzrNnSfOjsx-lHwVyDGrjlCiv82QYzs2A&usqp=CAU" />
			<img src="https://p.kindpng.com/picc/s/50-508065_free-cartoon-books-download-kids-books-cartoon-hd.png" />
			<img src="https://www.wallpapertip.com/wmimgs/13-134716_smiley-face-desktop-wallpaper-49025-src-smiley-face.jpg" />
		  </div>
		  
		  <div class="column">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrjnFNPWuGEZ1Mq6fOW4tf7h-bTZcrk7-zQizzrNnSfOjsx-lHwVyDGrjlCiv82QYzs2A&usqp=CAU" />
			
			<img src="https://res.cloudinary.com/updater-marketing/images/f_auto,q_auto/v1608674876/used-clothing-donation-b-2/used-clothing-donation-b-2.jpg" />
	 
			
		   
		  </div>
		  
		  <div class="column">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrjnFNPWuGEZ1Mq6fOW4tf7h-bTZcrk7-zQizzrNnSfOjsx-lHwVyDGrjlCiv82QYzs2A&usqp=CAU" />
			
		  </div>
		  <div class="column">
			<img src="https://www.simplyrecipes.com/thmb/j_IZxLEP2tJjonCl3s7RiGnMuxo=/2000x1331/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2020__02__HTC-White-Rice-Lead-4-e5743ee4c63a40a0aec2f3abd9f1c097.jpg" />
			<img src="https://p.kindpng.com/picc/s/50-508065_free-cartoon-books-download-kids-books-cartoon-hd.png"/>
			
		  </div>
		  <div class="column">
			<img src="https://www.simplyrecipes.com/thmb/j_IZxLEP2tJjonCl3s7RiGnMuxo=/2000x1331/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2020__02__HTC-White-Rice-Lead-4-e5743ee4c63a40a0aec2f3abd9f1c097.jpg" />
			<img src="https://res.cloudinary.com/updater-marketing/images/f_auto,q_auto/v1608674876/used-clothing-donation-b-2/used-clothing-donation-b-2.jpg" />
			<img src="https://media.newyorker.com/photos/5f2c85539a557880d973a759/1:1/w_1823,h_1823,c_limit/Buford-FrenchRice.jpg" />
			<img src="https://i.pinimg.com/originals/82/15/56/821556d35fd814575d7bc445987a57cc.jpg" />
			<img src="https://i.pinimg.com/originals/fa/c7/39/fac73900c96a27677a2e14398467440c.jpg" />
			<img src="https://res.cloudinary.com/updater-marketing/images/f_auto,q_auto/v1608674876/used-clothing-donation-b-2/used-clothing-donation-b-2.jpg" />
			<img src="https://www.simplyrecipes.com/thmb/j_IZxLEP2tJjonCl3s7RiGnMuxo=/2000x1331/filters:fill(auto,1)/__opt__aboutcom__coeus__resources__content_migration__simply_recipes__uploads__2020__02__HTC-White-Rice-Lead-4-e5743ee4c63a40a0aec2f3abd9f1c097.jpg" />
		  </div>
		  <div class="column">
		   <img src="https://thumbs.dreamstime.com/b/hand-drawn-illustration-clothes-donate-charity-care-concept-hand-drawn-illustration-clothes-donate-charity-care-concept-172184835.jpg" />
		   <img src="https://media.istockphoto.com/vectors/cardboard-box-with-books-for-donations-charity-colorful-vector-vector-id1178491737?k=6&m=1178491737&s=612x612&w=0&h=gyIsd771Ir_iH0B6sOJv-OvBtgO-nZP9xByAHhhGexg=" />
		   <img src="https://i.pinimg.com/originals/af/eb/7d/afeb7d261617e39d54bc023bcaf2739c.jpg" />
		   <img src="https://i.pinimg.com/474x/99/06/6f/99066fff5e69ba893213ee2671fc7dab.jpg" />
		   <img src="https://www.how-to-draw-funny-cartoons.com/image-files/cartoon-tv-5.gif" />
		   <img src="https://thumbs.dreamstime.com/b/hand-drawn-illustration-clothes-donate-charity-care-concept-hand-drawn-illustration-clothes-donate-charity-care-concept-172184835.jpg" />
		   <img src="https://media.istockphoto.com/vectors/cardboard-box-with-books-for-donations-charity-colorful-vector-vector-id1178491737?k=6&m=1178491737&s=612x612&w=0&h=gyIsd771Ir_iH0B6sOJv-OvBtgO-nZP9xByAHhhGexg=" />
		   
		 </div>
		  
		  
		</div>
	  </div>
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
  
    <form method='post' action='orphanage_requirements.php'>
	  <div class="head"><h1>Requirement Update</h1></div>
	  <div class="line"></div>
	   <div class="box">
		 <center> &nbsp;&nbsp;<h1><span>U</span>pdate</h1></center>
		  <center>&nbsp;&nbsp;<h3 style="font-size:30px;">Choose your requirements</h3></center>  
		  <br>
		  <br>
	    <div align="center" style="font-size:20px"><b>
        <tr><td><input type="checkbox" id="1" name="needs[]" value="Kitchen ware" >
        <label for="1">Kitchen ware</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="2" name="needs[]" value="Clothes" >
        <label for="2">Clothes</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="3" name="needs[]" value="Activity&Books" >
        <label for="3">Activity&Books</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="4" name="needs[]" value="Pens/Pencils">
        <label for="4">Pens/Pencils</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="5" name="needs[]" value="Notes" >
        <label for="5">Notes</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="6" name="needs[]" value="School Bags" >
        <label for="6">School Bags</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="7" name="needs[]" value="Toys" >
        <label for="7">Toys</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="8" name="needs[]" value="Pulses/Dals" >
        <label for="8">Pulses/Dals</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="9" name="needs[]" value="Beds/Cots" >
        <label for="9">Beds/Cots</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="10" name="needs[]" value="Bed Sheets" >
        <label for="10">Bed Sheets</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="11" name="needs[]" value="Plates/Glasses" >
        <label for="11">Plates/Glasses</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="12" name="needs[]" value="Fridge" >
        <label for="12">Fridge</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="13" name="needs[]" value="Rice" >
        <label for="13">Rice</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="14" name="needs[]" value="Snacks" >
        <label for="14">Snacks</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="15" name="needs[]" value="Telivision" >
        <label for="15">Telivision</label></td></tr><br><br>
        <tr><td><input type="checkbox" id="16" name="needs[]" value="Money" >
        <label for="16">Money</label></td></tr><br><br>
		
		
		<table style="font-size:20px;align:center;">
		<tr>
		<td>Your other requirements :&emsp;<input type="text" name="name"></td>
		</tr>
		</table>
		</div></b>
		<div class="popup center">
		   <div class="icon">
			 <i class="fa fa-check"></i>
		   </div>
		   <div class="title">
			 Successfully updated!!
		   </div>

		   <div class="dismiss-btn">
			 <button id="dismiss-popup-btn">
			   Dismiss
			 </button>
		   </div>
		 </div>
		 <div allign="center">
		 <tr><td><input type="submit"  value="UPDATE" class="button" name="submit" >
		 </div>
		
	</form>     
		
		
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	   <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
	   <script>
	   var html = '<tr><td><tr><td><input type="text" name="name"></td><td><button class="remove">-</button></td></tr>';
		
	   $(function() {
		$('tbody').sortable();
		
		$('#addRow').click(function(){
		$('tbody').append(html);
		});
		
		$(document).on('click', '.remove', function() {
		$(this).parents('tr').remove();
		});
		
		$('#getValues').click(function(){
		var values = [];
		$(<tr><td>'input[name="name"]').each(function(i, elem){
		values.push($(elem).val());
		});
		alert(values.join(', '));
		});
	   });
	   </script>
	  </div>
	
   <script type="text/javascript">
		const toggleBtns = document.querySelectorAll('.toggle-box');
	  toggleBtns.forEach((btn) => {
		  btn.addEventListener('click', () => {
			  btn.classList.toggle('toggle-pressed');
		  })
	  })
   </script>
   <script  src="Requirment Update.js"></script>
</body>
</html>